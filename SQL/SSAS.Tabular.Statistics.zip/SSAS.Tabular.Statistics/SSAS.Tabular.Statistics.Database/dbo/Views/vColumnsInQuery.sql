﻿CREATE VIEW dbo.vColumnsInQuery
AS
SELECT [ColumnsInQueryId]
      ,[ColumnId]
      ,[QueryId]
FROM [dbo].[ColumnsInQuery]