﻿CREATE VIEW dbo.vDatabases
AS
SELECT [DatabaseId]
      ,[DatabaseName]
  FROM [dbo].[Databases]