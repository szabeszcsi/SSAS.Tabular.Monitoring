﻿CREATE VIEW dbo.vColumns
AS
SELECT [ColumnId]
      ,[TableId]
      ,[ColumName]
      ,[IsActive]
FROM [dbo].[Columns]