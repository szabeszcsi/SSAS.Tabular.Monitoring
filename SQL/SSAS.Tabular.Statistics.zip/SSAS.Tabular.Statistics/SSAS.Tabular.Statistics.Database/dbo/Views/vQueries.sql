﻿CREATE VIEW dbo.vQueries
AS
SELECT [QueryId]
      ,[QueryText]
      --,[QueryHash]
FROM [dbo].[Queries]