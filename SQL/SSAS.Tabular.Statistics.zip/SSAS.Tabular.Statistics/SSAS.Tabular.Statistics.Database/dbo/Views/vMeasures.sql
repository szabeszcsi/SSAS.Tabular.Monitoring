﻿CREATE VIEW dbo.vMeasures
AS
SELECT [MeasureId]
      ,[TableId]
      ,[MeasureName]
      ,[IsActive]
FROM [dbo].[Measures]