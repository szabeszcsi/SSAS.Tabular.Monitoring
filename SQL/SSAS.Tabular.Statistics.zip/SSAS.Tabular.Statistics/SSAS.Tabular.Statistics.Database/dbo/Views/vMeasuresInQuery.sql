﻿CREATE VIEW dbo.vMeasuresInQuery
AS
SELECT [MeasuresInQueryId]
      ,[MeasureId]
      ,[QueryId]
  FROM [dbo].[MeasuresInQuery]