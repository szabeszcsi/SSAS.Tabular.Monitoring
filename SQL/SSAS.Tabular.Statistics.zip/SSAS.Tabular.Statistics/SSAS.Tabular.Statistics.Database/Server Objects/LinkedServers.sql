﻿EXECUTE sp_addlinkedserver @server = N'SSAS', @srvproduct = N'MSOLAP', @provider = N'MSOLAP', @datasrc = N'TSZDELL2015\SQL2017';

